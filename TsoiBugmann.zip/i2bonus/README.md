Alumnos: 
Samantha Tsoi, 19404107
Joaquin Bugmann, 14637138

Instrucciones:
En seq.sql, para ejecutar la funcion seq con 3 parámetros, necesite las tablas A con las columnas a y b, y B con las columnas a y b. Entonces, ejecute la funcion como esta en los ejemplos. Por ejemplo, SELECT * FROM seq(1,5,1);

En cruz.sql, para encontrar un procedimiento almacenado que calcule el producto cruz de A y B, necesite las tablas A con las columnas a y b, y B con las columnas a y b. Entonces, ejecute la funcion. Por ejemplo, SELECT * FROM cruz();

En vuelo_cacheando.sql, para encontrar todos los lugares a los que puedes llegar volando desde Santiago, necesite la tabla Vuelos. Entonces, ejecute la funcion con un parametro de ciudad. Por ejemplo, SELECT vuelo_cacheando('Santiago');